package com.example.timer;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    TextView title;
    TextView time;
    EditText type;

    Handler handler=new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            time.setText((String) msg.obj);
        }
    };

    Timer.OntimeChangeListener listener=new Timer.OntimeChangeListener() {
        @Override
        public void OntimeChange(long time) {
            Message message=new Message();
            message.obj=TimetoString(time);
            handler.sendMessage(message);
            ChangeTime(time);
        }

        @SuppressLint("SetTextI18n")
        @Override
        public void Onstop() {

        }
    };

    Timer timer=new Timer(listener);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.e("activity", "MainActivity-onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        title=findViewById(R.id.tv_title);
        time=findViewById(R.id.tv_timer);
        type=findViewById(R.id.edt_type);
        type.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                ChangeType(s.toString());
            }
        });
        title.setText(GetTime());
        type.setText(GetType());
        findViewById(R.id.iv_start).setOnClickListener(this);
        findViewById(R.id.iv_pause).setOnClickListener(this);
        findViewById(R.id.iv_stop).setOnClickListener(this);
    }

    @SuppressLint({"NonConstantResourceId", "SetTextI18n"})
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.iv_start:
                if (timer.getState()!=1)
                    timer.Start_Pause();
                break;
            case R.id.iv_pause:
                if (timer.getState()==1)
                    timer.Start_Pause();
                break;
            case R.id.iv_stop:
                timer.Stop();
                title.setText("You spent "+TimetoString(timer.GetTime())+" on "+type.getText().toString()+" last time.");
                break;
        }
    }

    @SuppressLint("DefaultLocale")
    private String autoGenericCode(long num) {
        String result;
        result = String.format("%2d", num).replaceAll(" ","0");
        return result;
    }

    public String TimetoString(long totaltime){
        long hour;
        long min;
        long second;
        second= totaltime /1000;
        min=second/60;
        second%=60;
        hour=min/60;
        second%=60;
        return autoGenericCode(hour)+":"+autoGenericCode(min)+":"+autoGenericCode(second);
    }

    public String GetTime(){
        SharedPreferences sharedPreferences=getSharedPreferences("data",Context.MODE_PRIVATE);
        long time=sharedPreferences.getLong("time",0);
        return "You spent "+TimetoString(time)+" on "+GetType()+" last time.";
    }

    public String GetType(){
        SharedPreferences sharedPreferences=getSharedPreferences("data",Context.MODE_PRIVATE);
        return sharedPreferences.getString("type","push ups");
    }

    public void ChangeType(String type){
        SharedPreferences sharedPreferences=getSharedPreferences("data",Context.MODE_PRIVATE);
        @SuppressLint("CommitPrefEdits")
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.remove("type");
        editor.putString("type",type);
        editor.apply();
    }

    public void ChangeTime(long data){
        SharedPreferences sharedPreferences=getSharedPreferences("data",Context.MODE_PRIVATE);
        @SuppressLint("CommitPrefEdits")
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.remove("time");
        editor.putLong("time",data);
        editor.apply();
    }

}