package com.example.timer;

import android.annotation.SuppressLint;

public class Timer{
    
    private int state=0;
    private long totaltime;
    private long sec;
    private final OntimeChangeListener listener;

    Timer(OntimeChangeListener listener){
        this.listener=listener;
    }

    void Start_Pause(){
        if (state==1){
            state=2;
            return;
        }
        if (state==0){
            state=1;
            totaltime =0;
            sec =0;
            new TimeThread().start();
        }
        state=1;
    }

    void Stop(){
        state=0;
        if (listener!=null){
            listener.Onstop();
        }
    }

    public int getState(){
        return state;
    }

    @SuppressLint("DefaultLocale")
    private String autoGenericCode(long num) {
        String result;
        result = String.format("%2d", num).replaceAll(" ","0");
        return result;
    }

    public long GetTime(){
        return totaltime;
    }

    class TimeThread extends Thread{

        @Override
        public void run() {
            long lasttime = System.currentTimeMillis();
            while (state!=0){
                if (state!=2){
                    long currenttime=System.currentTimeMillis();
                    totaltime +=currenttime- lasttime;
                    lasttime =currenttime;
                    if(totaltime /1000> sec){
                        sec = totaltime /1000;
                        if (listener!=null){
                            listener.OntimeChange(GetTime());
                        }
                    }
                }

            }
        }
    }

    interface OntimeChangeListener{
        void OntimeChange(long time);
        void Onstop();
    }
}